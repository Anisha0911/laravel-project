

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Admin Dashboard</h2>
</div>

<!-- Stats -->
<div class="row g-4 mb-4">

    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Total Users</small>
                    <h3 class="fw-bold mb-0"><?php echo e($users->count()); ?></h3>
                </div>
                <i class="bi bi-people fs-1 text-success"></i>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Total Projects</small>
                    <h3 class="fw-bold mb-0">
                        <?php echo e($projects->count()); ?>

                    </h3>
                </div>
                <i class="bi bi-kanban fs-1 text-success"></i>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Total Tasks</small>
                    <h3 class="fw-bold mb-0">
                        <?php echo e($task->count()); ?>

                    </h3>
                </div>
                <i class="bi bi-list-task fs-1 text-success"></i>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Admins</small>
                    <h3 class="fw-bold mb-0">
                        <?php echo e($users->where('role','admin')->count()); ?>

                    </h3>
                </div>
                <i class="bi bi-shield-lock fs-1 text-success"></i>
            </div>
        </div>
    </div>

    <!-- Completed Projects -->
    <div class="col-md-3">
        <div class="card shadow-sm border-0 bg-success bg-opacity-10">
            <div class="card-body">
                <small class="text-success fw-semibold">
                    Completed Tasks
                </small>
                <h3 class="fw-bold text-success">
                    <?php echo e($completedTasks); ?>

                </h3>
            </div>
        </div>
    </div>

    <!-- Pending Projects -->
    <div class="col-md-3">
        <div class="card shadow-sm border-0 bg-warning bg-opacity-10">
            <div class="card-body">
                <small class="text-warning fw-semibold">
                    Pending Tasks
                </small>
                <h3 class="fw-bold text-warning">
                    <?php echo e($pendingTasks); ?>

                </h3>
            </div>
        </div>
    </div>

    <!-- <div class="col-sm-6 col-lg-4">
        <div class="card shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Normal Users</small>
                    <h3 class="fw-bold mb-0">
                        <?php echo e($users->where('role','user')->count()); ?>

                    </h3>
                </div>
                <i class="bi bi-person fs-1 text-secondary"></i>
            </div>
        </div>
    </div> -->

</div>

<!-- Users Table -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white fw-semibold">
        Users List
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <span class="badge <?php echo e($user->role == 'admin' ? 'bg-primary' : 'bg-secondary'); ?>">
                            <?php echo e(ucfirst($user->role)); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>