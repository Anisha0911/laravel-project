

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <!-- Page Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
        <h2 class="fw-bold mb-3 mb-md-0">Task Details</h2>
        <a href="<?php echo e(route('admin.tasks.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to Tasks
        </a>
    </div>

    <!-- Task Details Card -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h4><?php echo e($task->title); ?></h4>
            <p><strong>Project:</strong> <?php echo e($task->project->name); ?></p>
            <p><strong>Assigned To:</strong> <?php echo e($task->user->name); ?></p>
             <?php
    // Status Colors
    $statusColors = [
        'pending' => 'secondary',
        'in_progress' => 'primary',
        'review' => 'warning',
        'hold' => 'dark',
        'completed' => 'success',
    ];

    // Priority Colors
    $priorityColors = [
        'low' => 'success',
        'medium' => 'warning',
        'high' => 'danger',
        'urgent' => 'dark',
    ];
?>

<p>
    <strong>Status:</strong> 
    <span class="badge bg-<?php echo e($statusColors[$task->status] ?? 'secondary'); ?>">
        <?php echo e(ucfirst(str_replace('_', ' ', $task->status))); ?>

    </span>
</p>

<p>
    <strong>Priority:</strong> 
    <span class="badge bg-<?php echo e($priorityColors[$task->priority] ?? 'secondary'); ?>">
        <?php echo e(ucfirst($task->priority)); ?>

    </span>
</p>
<!-- ------------------------------------- -->
            <p><strong>Due Date:</strong> <?php echo e($task->due_date ? $task->due_date->format('Y-m-d') : 'N/A'); ?></p>
            <p><?php echo e($task->description); ?></p>
        </div>
    </div>

    <!-- Task Comments Section -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h4>Task Discussion</h4>

            <form method="POST" action="<?php echo e(route('tasks.comments.store', $task)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-12">
                        <textarea name="comment" rows="3" class="form-control" placeholder="Write a comment..." required></textarea>
                    </div>
                    <div class="col-12 col-md-3">
                        <input type="file" name="file" class="form-control">
                    </div>
                    <div class="col-12 col-md-3">
                        <input type="file" name="audio" accept="audio/*" class="form-control">
                    </div>
                    <div class="col-12 col-md-3">
                        <button type="submit" class="btn btn-primary">Add Comment</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Display Comments -->
    <?php $__currentLoopData = $task->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-2">
        <div class="card-body">
            <strong><?php echo e($comment->user->name); ?></strong>
            <small>(<?php echo e($comment->created_at->diffForHumans()); ?>)</small>
            <p><?php echo e($comment->comment); ?></p>

            <?php if($comment->file_path): ?>
                <a href="<?php echo e(asset('storage/'.$comment->file_path)); ?>" target="_blank">📎 Download File</a>
            <?php endif; ?>

            <?php if($comment->audio_path): ?>
                <audio controls>
                    <source src="<?php echo e(asset('storage/'.$comment->audio_path)); ?>">
                </audio>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/admin/tasks/show.blade.php ENDPATH**/ ?>