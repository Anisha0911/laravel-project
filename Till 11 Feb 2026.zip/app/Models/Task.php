<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $fillable = [
        'title',
        'description',
        'project_id',
        'user_id',
        'status',
        'due_date',
        'priority',
        'created_date'
    ];

    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    protected $casts = [
    'due_date' => 'datetime',
    'created_date' => 'datetime',
    ];

    public function comments()
    {
        return $this->hasMany(TaskComment::class);
    }

}
