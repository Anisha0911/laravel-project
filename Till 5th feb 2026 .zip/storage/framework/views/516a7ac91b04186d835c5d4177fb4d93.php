

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Tasks for Project: <?php echo e($project->name); ?></h3>

    <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-2 shadow-sm">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <strong><?php echo e($task->title); ?></strong>
                    <p><?php echo e($task->description ?? ''); ?></p>
                </div>
                <div>
                    <a href="<?php echo e(route('user.tasks.show', $task->id)); ?>" class="btn btn-sm btn-primary">
                        View Task
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No tasks assigned to you in this project.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/projects/tasks.blade.php ENDPATH**/ ?>