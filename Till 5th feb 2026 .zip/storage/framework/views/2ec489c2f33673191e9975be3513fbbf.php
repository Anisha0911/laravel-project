

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>My Projects</h3>

    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-2 shadow-sm">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <strong><?php echo e($project->name); ?></strong>
                    <p class="mb-0"><?php echo e($project->description ?? ''); ?></p>
                </div>
                <div>
                    <?php
                        // Get the first task assigned to this user for this project
                        $task = $project->tasks()->where('user_id', auth()->id())->first();
                    ?>

                    <?php if($task): ?>
<a href="<?php echo e(route('user.projects.tasks', $project->id)); ?>" class="btn btn-sm btn-primary">
    View My Tasks
</a>
                    <?php else: ?>
                        <span class="text-muted">No tasks assigned</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No projects assigned to you.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/projects/index.blade.php ENDPATH**/ ?>