<h3>Notifications</h3>

<?php $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $taskId = $notification->data['task_id'];
        $routeUrl = auth()->user()->role === 'admin' 
            ? url('/admin/tasks/'.$taskId)   // Admin URL
            : url('/user/tasks/'.$taskId);   // User URL
    ?>

    <div style="border:1px solid #ccc;padding:10px;margin-bottom:10px">
        <?php echo e($notification->data['message']); ?>

        <br>
        <a href="<?php echo e($routeUrl); ?>">
            View Task
        </a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\task-management\resources\views/notifications/index.blade.php ENDPATH**/ ?>