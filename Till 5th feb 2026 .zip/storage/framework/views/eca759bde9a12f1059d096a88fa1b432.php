

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Your Tasks</h2>

    <?php if($tasks->isEmpty()): ?>
        <p>No tasks assigned to you yet.</p>
    <?php else: ?>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Project</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($task->title); ?></td>
                    <td><?php echo e($task->project->name); ?></td>
                    <td><?php echo e(ucfirst($task->status)); ?></td>
                    <td><?php echo e($task->due_date ? $task->due_date->format('Y-m-d') : 'N/A'); ?></td>
                    <td>
                        <a href="<?php echo e(route('user.tasks.show', $task)); ?>" class="btn btn-primary btn-sm">
                            View Task
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/tasks/index.blade.php ENDPATH**/ ?>