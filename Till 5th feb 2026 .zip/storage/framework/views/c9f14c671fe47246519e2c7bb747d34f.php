<aside class="bg-white border-end sidebar-desktop h-100">

    <div class="p-4 border-bottom">
        <h6 class="fw-bold mb-0">User Panel</h6>
    </div>

    <ul class="nav flex-column p-3 gap-1">

        <li class="nav-item">
            <a href="<?php echo e(route('user.dashboard')); ?>"
               class="nav-link <?php echo e(request()->is('user/dashboard') ? 'active bg-primary text-white rounded' : 'text-dark'); ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('user.projects.index')); ?>"
               class="nav-link <?php echo e(request()->is('user/projects*') ? 'active bg-primary text-white rounded' : 'text-dark'); ?>">
                <i class="bi bi-kanban me-2"></i> My Projects
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('user.tasks.index')); ?>"
               class="nav-link <?php echo e(request()->is('user/tasks*') ? 'active bg-primary text-white rounded' : 'text-dark'); ?>">
                <i class="bi bi-list-task me-2"></i> My Tasks
            </a>
        </li>

        <li class="nav-item">
            <a href="#"
               class="nav-link text-dark">
                <i class="bi bi-gear me-2"></i> Settings
            </a>
        </li>

    </ul>

    <!-- Footer -->
    <!-- Footer / Logged in as -->
    <div class="p-3 border-top mt-auto text-center">
        <small class="text-muted d-block">Logged in as</small>
        <div class="fw-semibold"><?php echo e(auth()->user()->name); ?></div>
        <img src="<?php echo e(auth()->user()->profile_photo_url ?? 'https://via.placeholder.com/40'); ?>"
             alt="profile" class="rounded-circle mt-2" style="width:40px; height:40px;">
    </div>

</aside>
<?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/sidebar.blade.php ENDPATH**/ ?>