@extends('layouts.user')

@section('content')
<div class="container mt-5">
    <h2>Your Tasks</h2>

    @if($tasks->isEmpty())
        <p>No tasks assigned to you yet.</p>
    @else
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Project</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($tasks as $task)
                <tr>
                    <td>{{ $task->title }}</td>
                    <td>{{ $task->project->name }}</td>
                    <td>{{ ucfirst($task->status) }}</td>
                    <td>{{ $task->due_date ? $task->due_date->format('Y-m-d') : 'N/A' }}</td>
                    <td>
                        <a href="{{ route('user.tasks.show', $task) }}" class="btn btn-primary btn-sm">
                            View Task
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>
@endsection
