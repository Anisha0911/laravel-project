@extends('layouts.admin')

<style>
    /* ================= FILTER BAR ================= */
    .filter-wrapper {
        overflow: hidden;
    }
    .filter-scroll {
        display: flex;
        gap: 14px;
        overflow-x: auto;
        padding-bottom: 8px;
    }
    .filter-scroll::-webkit-scrollbar {
        height: 5px;
    }
    .filter-scroll::-webkit-scrollbar-thumb {
        background: #ddd;
        border-radius: 10px;
    }

    /* Filter Cards */
    .filter-box {
        min-width: 130px;
        background: #fff;
        border: 1px solid #f0f0f0;
        border-radius: 14px;
        padding: 2px 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        white-space: nowrap;
        box-shadow: 0 2px 10px rgba(0,0,0,0.04);
        cursor: pointer;
        transition: 0.25s ease;
    }
    .filter-box strong {
        font-size: 18px;
        font-weight: 700;
    }
    .filter-box:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    }
    .filter-box.active {
        background: linear-gradient(135deg,#0d6efd,#6610f2);
        color: #fff !important;
        border-color: transparent;
    }
    .filter-box.active strong,
    .filter-box.active span {
        color: #fff;
    }

    /* Table UI */
    .table-hover tbody tr:hover {
        background: #f9fbff;
    }
    .sticky-header thead th {
        position: sticky;
        top: 0;
        background: #212529;
        z-index: 5;
        color: #fff;
    }

    /* Highlight pinned tasks */
    .tr-pinned {
        border-left: 5px solid #ffc107 !important;
        background: #fffdf3;
    }

    /* Cards Hover */
    .card {
        border-radius: 16px;
        transition: .25s ease;
    }
    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 30px rgba(0,0,0,.07);
    }

    /* Status badge bigger */
    .badge {
        padding: 6px 12px;
        font-size: 12px;
        border-radius: 20px;
    }

    /* Action Button */
    .btn-view {
        border-radius: 20px;
        padding: 4px 14px;
        font-size: 13px;
    }
</style>

@section('content')
<div class="container-fluid mt-4">

    <!-- ================= HEADER ================= -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">My Tasks</h2>
            <p class="text-muted small mb-0">Manage all tasks assigned to you</p>
        </div>

        <!-- Search -->
        <form method="GET" action="{{ route('user.tasks.index') }}" class="w-auto">
            <div class="input-group input-group-sm shadow-sm rounded-pill overflow-hidden">
                <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-search text-muted"></i>
                </span>
                <input type="text"
                       name="search"
                       value="{{ request('search') }}"
                       class="form-control border-start-0"
                       placeholder="Search tasks...">
            </div>
        </form>
    </div>

    <!-- ================= FILTER CARDS ================= -->
    <div class="filter-wrapper mb-4">
        <div class="filter-scroll">

            <div class="filter-box active" data-filter="all">
                <span>All Tasks</span>
                <strong>{{ $tasks->count() }}</strong>
            </div>

            <div class="filter-box text-success" data-filter="completed">
                <span>Completed</span>
                <strong>{{ $completedCount }}</strong>
            </div>

            <div class="filter-box text-primary" data-filter="in_progress">
                <span>In Progress</span>
                <strong>{{ $inProgressCount }}</strong>
            </div>

            <div class="filter-box text-dark" data-filter="hold">
                <span>On Hold</span>
                <strong>{{ $holdCount }}</strong>
            </div>

            <div class="filter-box text-secondary" data-filter="pending">
                <span>Pending</span>
                <strong>{{ $pendingCount }}</strong>
            </div>

            <div class="filter-box text-success" data-filter="in_time">
                <span>In Time</span>
                <strong>{{ $inTimeCount }}</strong>
            </div>

            <div class="filter-box text-danger" data-filter="delayed">
                <span>Delayed</span>
                <strong>{{ $delayedCount }}</strong>
            </div>

            <!-- Date Picker -->
            <div class="filter-box date-filter">
                <i class="bi bi-calendar-event"></i>
                <input type="date" id="dateFilter" class="form-control form-control-sm border-0">
            </div>
        </div>
    </div>

    <!-- ================= BULK ACTIONS ================= -->
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div>
            <input type="checkbox" id="selectAll" class="form-check-input me-2">
            <label for="selectAll" class="form-check-label fw-semibold">Select All</label>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-sm btn-success rounded-pill px-3" id="bulkComplete">
                <i class="bi bi-check-circle"></i> Complete
            </button>
            <button class="btn btn-sm btn-danger rounded-pill px-3" id="bulkDelete">
                <i class="bi bi-trash"></i> Delete
            </button>
        </div>
    </div>

    <!-- ================= TASK TABLE ================= -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 sticky-header">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="headerCheckbox"></th>
                            <th>Task</th>
                            <th>Created</th>
                            <th>Status</th>
                            <th>Priority</th>
                            <th>Due Date</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>

                    <tbody id="taskTableBody">
                        @forelse($tasks as $task)
                            @php
                                $statusMap = [
                                    'pending' => ['secondary', 'bi-clock'],
                                    'in_progress' => ['primary', 'bi-arrow-repeat'],
                                    'review' => ['warning', 'bi-eye'],
                                    'hold' => ['dark', 'bi-pause-circle'],
                                    'completed' => ['success', 'bi-check-circle'],
                                ];
                                $priorityMap = [
                                    'low' => ['success', 'bi-arrow-down'],
                                    'medium' => ['warning', 'bi-dash-circle'],
                                    'high' => ['danger', 'bi-arrow-up'],
                                    'urgent' => ['dark', 'bi-exclamation-triangle'],
                                ];
                                $statusColor = $statusMap[$task->status][0] ?? 'secondary';
                                $statusIcon  = $statusMap[$task->status][1] ?? 'bi-question-circle';
                                $priorityColor = $priorityMap[$task->priority][0] ?? 'secondary';
                                $priorityIcon  = $priorityMap[$task->priority][1] ?? 'bi-dash';
                            @endphp

                            <tr class="{{ $task->is_pinned ? 'tr-pinned' : '' }}">
                                <td><input type="checkbox" class="task-checkbox" value="{{ $task->id }}"></td>

                                <td class="fw-semibold">
                                    {{ $task->title }}
                                    <div class="small text-muted">{{ $task->project->name ?? '' }}</div>
                                </td>

                                <td class="text-muted">
                                    {{ $task->created_at->format('d M Y') }}
                                </td>

                                <td>
                                    <span class="badge bg-{{ $statusColor }}">
                                        <i class="bi {{ $statusIcon }}"></i>
                                        {{ ucfirst(str_replace('_',' ',$task->status)) }}
                                    </span>
                                </td>

                                <td>
                                    <span class="badge bg-{{ $priorityColor }}">
                                        <i class="bi {{ $priorityIcon }}"></i>
                                        {{ ucfirst($task->priority) }}
                                    </span>
                                </td>

                                <td class="text-muted">
                                    {{ $task->due_date ? $task->due_date->format('d M Y') : 'N/A' }}
                                </td>

                                <td class="text-center">
                                    <a href="{{ route('user.tasks.show', $task) }}" class="btn btn-sm btn-primary btn-view">
                                        <i class="bi bi-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    No tasks assigned.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

{{-- YOUR SAME JS CODE BELOW (UNCHANGED) --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    const filters = document.querySelectorAll('.filter-box[data-filter]');
    const tableBody = document.getElementById('taskTableBody');
    const dateInput = document.getElementById('dateFilter');
    const selectAll = document.getElementById('selectAll');
    const bulkComplete = document.getElementById('bulkComplete');
    const bulkDelete = document.getElementById('bulkDelete');

    function fetchFilteredTasks(status = '', date = '') {
        const params = new URLSearchParams({status, date});
        fetch(`{{ route('user.tasks.ajaxFilter') }}?${params}`)
            .then(res => res.json())
            .then(data => {
                tableBody.innerHTML = data.rows;
                Object.entries(data.counts).forEach(([key, val]) => {
                    const el = document.querySelector(`.filter-box[data-filter="${key}"] strong`);
                    if(el) el.textContent = val;
                });
            });
    }

    filters.forEach(f => {
        f.addEventListener('click', function() {
            filters.forEach(box => box.classList.remove('active'));
            this.classList.add('active');
            fetchFilteredTasks(this.dataset.filter, dateInput.value || '');
        });
    });

    dateInput.addEventListener('change', function() {
        const activeFilter = document.querySelector('.filter-box.active');
        fetchFilteredTasks(activeFilter.dataset.filter || '', this.value);
    });

    selectAll.addEventListener('change', function() {
        document.querySelectorAll('.task-checkbox').forEach(cb => cb.checked = selectAll.checked);
    });

    function getSelectedTaskIds() {
        return Array.from(document.querySelectorAll('.task-checkbox:checked')).map(cb => cb.value);
    }

    bulkComplete.addEventListener('click', function() {
        const ids = getSelectedTaskIds();
        if(ids.length === 0) return alert('Select tasks first.');
        fetch('{{ route("user.tasks.bulkComplete") }}', {
            method: 'POST',
            headers: {'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}'},
            body: JSON.stringify({ids})
        }).then(()=> location.reload());
    });

    bulkDelete.addEventListener('click', function() {
        const ids = getSelectedTaskIds();
        if(ids.length === 0) return alert('Select tasks first.');
        if(!confirm('Are you sure to delete selected tasks?')) return;
        fetch('{{ route("user.tasks.bulkDelete") }}', {
            method: 'POST',
            headers: {'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}'},
            body: JSON.stringify({ids})
        }).then(()=> location.reload());
    });
});
</script>

@endsection
