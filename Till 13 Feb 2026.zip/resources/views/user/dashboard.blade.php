@extends('layouts.admin')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">User Dashboard</h2>
</div>

<!-- Stats Cards -->
<div class="row g-4 mb-4">

    <!-- Projects -->
    <div class="col-sm-6 col-lg-4">
        <div class="stat-card bg-gradient-projects">
            <div>
                <small>Total Projects</small>
                <h3 class="fw-bold">{{ $projects }}</h3>
            </div>
            <i class="bi bi-kanban"></i>
        </div>
    </div>

    <!-- Tasks -->
    <div class="col-sm-6 col-lg-4">
        <div class="stat-card bg-gradient-tasks">
            <div>
                <small>Total Tasks</small>
                <h3 class="fw-bold">{{ $tasks }}</h3>
            </div>
            <i class="bi bi-list-task"></i>
        </div>
    </div>

    <!-- Completed -->
    <div class="col-sm-6 col-lg-4">
        <div class="stat-card bg-gradient-users">
            <div>
                <small>Completed Tasks</small>
                <h3 class="fw-bold">{{ $completedTasks }}</h3>
            </div>
            <i class="bi bi-check-circle"></i>
        </div>
    </div>

</div>

<!-- My Projects Table -->
<div class="card shadow-sm border-0">
    <div class="card-header fw-semibold bg-white">
        My Projects
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Project Name</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach($myProjects as $project)
                <tr>
                    <td>{{ $project->name }}</td>
                    <td>
                        <span class="badge {{ $project->status == 'completed' ? 'bg-success' : 'bg-warning' }}">
                            {{ ucfirst($project->status) }}
                        </span>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@endsection
