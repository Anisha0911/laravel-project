@extends('layouts.admin')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">📊 Admin Dashboard</h2>

    <!-- Dark Mode Toggle -->
    <button id="darkModeToggle" class="btn btn-outline-dark btn-sm">
        🌙 Dark Mode
    </button>
</div>

<!-- Stats Cards -->
<div class="row g-4 mb-4">

    <div class="col-md-3">
        <div class="stat-card bg-gradient-users">
            <h6>Total Users</h6>
            <h2 class="fw-bold">{{ $users->count() }}</h2>
            <i class="bi bi-people"></i>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card bg-gradient-projects">
            <h6>Total Projects</h6>
            <h2 class="fw-bold">{{ $projects->count() }}</h2>
            <i class="bi bi-kanban"></i>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card bg-gradient-tasks">
            <h6>Total Tasks</h6>
            <h2 class="fw-bold">{{ $task->count() }}</h2>
            <i class="bi bi-list-task"></i>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card bg-gradient-admins">
            <h6>Admins</h6>
            <h2 class="fw-bold">{{ $users->where('role','admin')->count() }}</h2>
            <i class="bi bi-shield-lock"></i>
        </div>
    </div>

</div>

<!-- Charts Row -->
<div class="row g-4 mb-4">

    <div class="col-md-6">
        <div class="card shadow-sm border-0 p-3">
            <h5 class="fw-bold">Task Status</h5>
            <canvas id="taskChart"></canvas>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card shadow-sm border-0 p-3">
            <h5 class="fw-bold">User Roles</h5>
            <canvas id="userChart"></canvas>
        </div>
    </div>

</div>

<!-- Users Table -->
<div class="card shadow-sm border-0">
    <div class="card-header fw-bold">👥 Users List</div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                </tr>
            </thead>
            <tbody>
                @foreach($users as $user)
                <tr>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>
                        <span class="badge {{ $user->role == 'admin' ? 'bg-primary' : 'bg-secondary' }}">
                            {{ ucfirst($user->role) }}
                        </span>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@endsection

@section('scripts')
<script>
// Dark Mode Toggle
document.getElementById('darkModeToggle').addEventListener('click', function () {
    document.body.classList.toggle('dark-mode');
});

// Task Status Chart
new Chart(document.getElementById('taskChart'), {
    type: 'doughnut',
    data: {
        labels: ['Completed', 'Pending'],
        datasets: [{
            data: [{{ $completedTasks }}, {{ $pendingTasks }}],
        }]
    }
});

// User Role Chart
new Chart(document.getElementById('userChart'), {
    type: 'bar',
    data: {
        labels: ['Admins', 'Users'],
        datasets: [{
            label: 'User Count',
            data: [
                {{ $users->where('role','admin')->count() }},
                {{ $users->where('role','user')->count() }}
            ],
        }]
    }
});
</script>
@endsection
