<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $statusMap = [
        'pending' => ['secondary', 'bi-clock'],
        'in_progress' => ['primary', 'bi-arrow-repeat'],
        'review' => ['warning', 'bi-eye'],
        'hold' => ['dark', 'bi-pause-circle'],
        'completed' => ['success', 'bi-check-circle'],
    ];
    $priorityMap = [
        'low' => ['success', 'bi-arrow-down'],
        'medium' => ['warning', 'bi-dash-circle'],
        'high' => ['danger', 'bi-arrow-up'],
        'urgent' => ['dark', 'bi-exclamation-triangle'],
    ];
    $statusColor = $statusMap[$task->status][0] ?? 'secondary';
    $statusIcon  = $statusMap[$task->status][1] ?? 'bi-question-circle';
    $priorityColor = $priorityMap[$task->priority][0] ?? 'secondary';
    $priorityIcon  = $priorityMap[$task->priority][1] ?? 'bi-dash';
?>
<tr>
    <td><input type="checkbox" class="task-checkbox" value="<?php echo e($task->id); ?>"></td>
    <td>
        <strong><?php echo e($task->title); ?></strong><br>
        <small class="text-muted"><?php echo e($task->project->name ?? ''); ?></small>
    </td>
    <td><?php echo e($task->created_at->format('d M Y')); ?></td>
    <td><span class="badge bg-<?php echo e($statusColor); ?>"><i class="bi <?php echo e($statusIcon); ?>"></i><?php echo e(ucfirst(str_replace('_',' ',$task->status))); ?></span></td>
    <td><span class="badge bg-<?php echo e($priorityColor); ?>"><i class="bi <?php echo e($priorityIcon); ?>"></i><?php echo e(ucfirst($task->priority)); ?></span></td>

    <td><?php echo e($task->due_date ?? 'N/A'); ?></td>
    <td class="text-center">
        <a href="<?php echo e(route('user.tasks.show',$task)); ?>" class="btn btn-sm btn-primary">View</a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/tasks/partials/task_rows.blade.php ENDPATH**/ ?>