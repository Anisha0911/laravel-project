

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">📊 Admin Dashboard</h2>

    <!-- Dark Mode Toggle -->
    <button id="darkModeToggle" class="btn btn-outline-dark btn-sm">
        🌙 Dark Mode
    </button>
</div>

<!-- Stats Cards -->
<div class="row g-4 mb-4">

    <div class="col-md-3">
        <div class="stat-card bg-gradient-users">
            <h6>Total Users</h6>
            <h2 class="fw-bold"><?php echo e($users->count()); ?></h2>
            <i class="bi bi-people"></i>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card bg-gradient-projects">
            <h6>Total Projects</h6>
            <h2 class="fw-bold"><?php echo e($projects->count()); ?></h2>
            <i class="bi bi-kanban"></i>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card bg-gradient-tasks">
            <h6>Total Tasks</h6>
            <h2 class="fw-bold"><?php echo e($task->count()); ?></h2>
            <i class="bi bi-list-task"></i>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card bg-gradient-admins">
            <h6>Admins</h6>
            <h2 class="fw-bold"><?php echo e($users->where('role','admin')->count()); ?></h2>
            <i class="bi bi-shield-lock"></i>
        </div>
    </div>

</div>

<!-- Charts Row -->
<div class="row g-4 mb-4">

    <div class="col-md-6">
        <div class="card shadow-sm border-0 p-3">
            <h5 class="fw-bold">Task Status</h5>
            <canvas id="taskChart"></canvas>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card shadow-sm border-0 p-3">
            <h5 class="fw-bold">User Roles</h5>
            <canvas id="userChart"></canvas>
        </div>
    </div>

</div>

<!-- Users Table -->
<div class="card shadow-sm border-0">
    <div class="card-header fw-bold">👥 Users List</div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <span class="badge <?php echo e($user->role == 'admin' ? 'bg-primary' : 'bg-secondary'); ?>">
                            <?php echo e(ucfirst($user->role)); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
// Dark Mode Toggle
document.getElementById('darkModeToggle').addEventListener('click', function () {
    document.body.classList.toggle('dark-mode');
});

// Task Status Chart
new Chart(document.getElementById('taskChart'), {
    type: 'doughnut',
    data: {
        labels: ['Completed', 'Pending'],
        datasets: [{
            data: [<?php echo e($completedTasks); ?>, <?php echo e($pendingTasks); ?>],
        }]
    }
});

// User Role Chart
new Chart(document.getElementById('userChart'), {
    type: 'bar',
    data: {
        labels: ['Admins', 'Users'],
        datasets: [{
            label: 'User Count',
            data: [
                <?php echo e($users->where('role','admin')->count()); ?>,
                <?php echo e($users->where('role','user')->count()); ?>

            ],
        }]
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>