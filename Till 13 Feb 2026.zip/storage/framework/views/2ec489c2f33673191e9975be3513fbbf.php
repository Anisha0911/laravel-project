
<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-4">

    <!-- ================= HEADER ================= -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
        <div>
            <h2 class="fw-bold mb-1">My Projects</h2>
            <p class="text-muted small mb-0">Projects assigned to you with task tracking access.</p>
        </div>

        <!-- Search -->
        <form method="GET" action="<?php echo e(route('user.projects.index')); ?>" class="w-auto">
            <div class="input-group input-group-sm shadow-sm rounded-pill overflow-hidden">
                <span class="input-group-text bg-white border-0 ps-3">
                    <i class="bi bi-search text-muted"></i>
                </span>
                <input type="text"
                       name="search"
                       value="<?php echo e(request('search')); ?>"
                       class="form-control border-0 shadow-none"
                       placeholder="Search projects...">
            </div>
        </form>
    </div>

    <!-- ================= FILTER TABS ================= -->
    <div class="d-flex flex-wrap gap-2 mb-3">

        <a href="<?php echo e(route('user.projects.index')); ?>" 
           class="btn btn-sm <?php echo e(request('status') == null ? 'btn-primary' : 'btn-outline-primary'); ?> rounded-pill px-3">
           All
        </a>

        <a href="<?php echo e(route('user.projects.index', ['status'=>'active'])); ?>" 
           class="btn btn-sm <?php echo e(request('status')=='active' ? 'btn-success' : 'btn-outline-success'); ?> rounded-pill px-3">
           Active
        </a>

        <a href="<?php echo e(route('user.projects.index', ['status'=>'completed'])); ?>" 
           class="btn btn-sm <?php echo e(request('status')=='completed' ? 'btn-secondary' : 'btn-outline-secondary'); ?> rounded-pill px-3">
           Completed
        </a>

    </div>

    <!-- ================= PROJECT TABLE ================= -->
    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-0">

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Project</th>
                            <th>Description</th>
                            <th>Timeline</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>

                            <!-- Project Name -->
                            <td class="fw-semibold">
                                <i class="bi bi-folder-fill text-primary me-1"></i>
                                <?php echo e($project->name); ?>

                            </td>

                            <!-- Description -->
                            <td class="text-muted small">
                                <?php echo e(\Illuminate\Support\Str::limit($project->description, 60) ?? '—'); ?>

                            </td>

<!-- TIMELINE -->
                            <td>
                                <?php
                                $start = $project->start_date ? \Carbon\Carbon::parse($project->start_date)->format('d M Y') : 'N/A';
                                    $end = $project->end_date ? \Carbon\Carbon::parse($project->end_date)->format('d M Y') : 'N/A';
                                    $today = \Carbon\Carbon::today();
                                    $tasks = $project->tasks()->where('user_id', auth()->id())->get();
                                    $totalTasks = $tasks->count();
                                    $completedTasks = $tasks->where('status', 'completed')->count();

                                    $timelineText = 'N/A';
                                    $timelineClass = 'bg-light text-dark border';

                                    if ($project->end_date) {
                                        $endDate = \Carbon\Carbon::parse($project->end_date);
                                        $diffDays = $today->diffInDays($endDate, false);

                                        if ($diffDays < 0) {
                                            $timelineText = 'Overdue by ' . abs($diffDays) . ' days';
                                            $timelineClass = 'bg-danger text-white';
                                        } elseif ($diffDays === 0) {
                                            $timelineText = 'Due Today';
                                            $timelineClass = 'bg-warning text-dark';
                                        } elseif ($diffDays === 1) {
                                            $timelineText = '1 day left';
                                            $timelineClass = 'bg-info text-dark';
                                        } else {
                                            $timelineText = $diffDays . ' days left';
                                            $timelineClass = 'bg-light text-dark border';
                                        }
                                    }
                                ?>
                                <span class="badge bg-light text-dark border">
                                    <?php echo e($start); ?> → <?php echo e($end); ?>

                                </span>
                                <span class="badge <?php echo e($timelineClass); ?>">
                                    <?php echo e($timelineText); ?>

                                </span>
                            </td>

                            <!-- STATUS -->
                            <td class="text-center">
                                <?php
                                    $statusText = 'Active';
                                    $statusClass = 'bg-success text-white';

                                    if ($totalTasks > 0 && $completedTasks == $totalTasks) {
                                        $completedDate = $tasks->where('status', 'completed')->max('updated_at');
                                        $statusText = 'Completed on ' . \Carbon\Carbon::parse($completedDate)->format('d M Y');
                                        $statusClass = 'bg-secondary text-white';
                                    }
                                ?>

                                <span class="badge <?php echo e($statusClass); ?>">
                                    <?php echo e($statusText); ?>

                                </span>
                            </td>


                            <!-- Action -->
                            <td class="text-center">
                                <?php if($tasks->count() > 0): ?>
                                    <a href="<?php echo e(route('user.projects.tasks', $project->id)); ?>" 
                                       class="btn btn-sm btn-primary rounded-pill px-3">
                                       <i class="bi bi-list-task me-1"></i> My Tasks
                                    </a>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border">No tasks</span>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                <i class="bi bi-folder-x fs-4"></i><br>
                                No projects assigned to you.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/projects/index.blade.php ENDPATH**/ ?>