<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<!-- Dashboard Cards -->
<style>
    .form-control {
    font-size: 14px;  /* normal text size */
    padding: 8px 12px;
}/* Make placeholder text smaller */
::placeholder {
    font-size: 12px !important;   /* change to 11px or 13px if you want */
    color: #9aa0a6;               /* optional: lighter color */
}

/* For Bootstrap inputs & textarea specifically */
.form-control::placeholder {
    font-size: 12px !important;
}


    .topbar .bi-bell:hover {
    color: #0d6efd;
    }
    .badge {
        font-size: 11px;
    }

    .stat-card {
        border-radius: 18px;
        padding: 20px;
        color: white;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 25px rgba(0,0,0,.15);
    }
    .stat-card i {
        font-size: 2.5rem;
        opacity: 0.3;
        position: absolute;
        right: 15px;
        bottom: 10px;
    }
    .bg-gradient-users { background: linear-gradient(135deg, #667eea, #764ba2); }
    .bg-gradient-projects { background: linear-gradient(135deg, #43cea2, #185a9d); }
    .bg-gradient-tasks { background: linear-gradient(135deg, #ff758c, #ff7eb3); }
    .bg-gradient-admins { background: linear-gradient(135deg, #f7971e, #ffd200); }
</style>
<style>
body {
    background: #f5f6fa;
    overflow-x: hidden;
}

/* Sidebar */
#sidebar {
    width: 260px;
    background: #1e293b;
    color: white;
    height: 100vh;
    position: fixed;
    transition: 0.3s ease;
    z-index: 1000;
}

#sidebar.collapsed {
    width: 80px;
}

#sidebar .nav-link {
    color: #cbd5e1;
    padding: 12px 15px;
    border-radius: 8px;
    margin-bottom: 3px;
}

#sidebar .nav-link.active,
#sidebar .nav-link:hover {
    background: #0d6efd;
    color: white;
}

#sidebar.collapsed span {
    display: none;
}

/* Sidebar header */
.sidebar-header {
    padding: 15px;
    font-weight: bold;
    font-size: 18px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

/* Content */
#content {
    margin-left: 260px;
    transition: 0.3s;
}

#sidebar.collapsed ~ #content {
    margin-left: 80px;
}

/* Top bar */
.topbar {
    background: white;
    padding: 10px 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}

/* Mobile */
@media(max-width: 991px) {
    #sidebar {
        left: -260px;
    }
    #sidebar.show {
        left: 0;
    }
    #content {
        margin-left: 0;
    }
}
@media(max-width: 991px) {
    #sidebar.show {
        box-shadow: 0 0 0 10000px rgba(0,0,0,0.5);
    }
}
</style>
</head>

<body>

<div class="d-flex">

    <!-- Sidebar -->
<div id="sidebar">
        <!-- Mobile Close Button -->
    <button id="closeSidebar" class="btn btn-danger d-lg-none m-2">
        <i class="bi bi-x-lg"></i>
    </button>
    <?php if(auth()->user()->role == 'admin'): ?>
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div>


    <!-- Main Content -->
    <div id="content" class="flex-grow-1">

        <!-- Top Navbar -->
        <div class="topbar d-flex justify-content-between align-items-center">

            <!-- Sidebar Toggle -->
            <button id="toggleSidebar" class="btn btn-outline-primary">
                <i class="bi bi-list"></i>
            </button>

            <div class="d-flex align-items-center gap-3 ms-auto">

                <!-- 🔔 Notifications -->
                <div class="dropdown me-3">
                    <a class="position-relative text-dark dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="bi bi-bell fs-4"></i>

                        <?php if(auth()->user()->unreadNotifications->count()): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge bg-danger">
                                <?php echo e(auth()->user()->unreadNotifications->count()); ?>

                            </span>
                        <?php endif; ?>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow p-2" style="width:280px;">
                        <li class="dropdown-header fw-bold">Notifications</li>

                        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li>
                                <a class="dropdown-item small">
                                    <?php echo e($notification->data['message'] ?? 'New Notification'); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="dropdown-item text-muted">No new notifications</li>
                        <?php endif; ?>

                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a href="<?php echo e(route('notifications.index')); ?>" class="dropdown-item text-center fw-bold">
                                View All Notifications
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- User Dropdown -->
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i> <?php echo e(auth()->user()->name); ?>

                    </button>

                    <ul class="dropdown-menu dropdown-menu-end shadow">
                        <li>
<?php if(auth()->user()->role == 'admin'): ?>
    <a class="dropdown-item" href="<?php echo e(route('admin.profile.edit')); ?>">
<?php else: ?>
    <a class="dropdown-item" href="<?php echo e(route('user.profile.edit')); ?>">
<?php endif; ?>
    <i class="bi bi-person me-2"></i> Edit Profile
</a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>

            </div>
        </div>

        <!-- Page Content -->
        <div class="p-4">
                    
        
        <!-- Success/Error Msg -->
    <!-- Success/Error Toast -->
<div class="position-fixed top-0 start-50 translate-middle-x mt-3 z-index-1050" style="min-width: 320px; max-width: 400px;">

    <?php if(session('success')): ?>
    <div id="successAlert" class="toast align-items-center text-bg-success border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                <i class="bi bi-check-circle me-2"></i>
                <?php echo e(session('success')); ?>

            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
    <div id="errorAlert" class="toast align-items-center text-bg-danger border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
    <?php endif; ?>

</div>


            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function() {

    const sidebar = document.getElementById("sidebar");
    const toggleBtn = document.getElementById("toggleSidebar");
    const closeBtn = document.getElementById("closeSidebar");

    // Open Sidebar
    toggleBtn.addEventListener("click", function() {
        if (window.innerWidth > 991) {
            sidebar.classList.toggle("collapsed");
        } else {
            sidebar.classList.add("show");
        }
    });

    // Close Sidebar (Mobile)
    closeBtn.addEventListener("click", function() {
        sidebar.classList.remove("show");
    });

});
// document.addEventListener("click", function(e) {
//     if (window.innerWidth <= 991) {
//         if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
//             sidebar.classList.remove("show");
//         }
//     }
// });
</script>
<?php echo $__env->make('components.delete-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/delete-modal.js')); ?>"></script>
<script src="//unpkg.com/alpinejs" defer></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\task-management\resources\views/layouts/admin.blade.php ENDPATH**/ ?>