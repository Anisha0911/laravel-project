

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">

    <!-- ===================== HEADER ===================== -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
        <div>
            <h2 class="fw-bold mb-1">Notifications</h2>
            <p class="text-muted small mb-0">
                View and manage your system notifications
            </p>
        </div>

        <!-- Search -->
        <!-- <form method="GET" action="<?php echo e(route('notifications.index')); ?>" class="w-auto">
            <div class="input-group input-group-sm shadow-sm">
                <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-search text-muted"></i>
                </span>
                <input type="text"
                       name="search"
                       value="<?php echo e(request('search')); ?>"
                       class="form-control border-start-0"
                       placeholder="Search notifications...">
            </div>
        </form> -->
    </div>


    <!-- ===================== STATS CARDS ===================== -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 text-center p-3">
                <small class="text-muted">Total</small>
                <h4 class="fw-bold mb-0"><?php echo e($totalCount); ?></h4>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 text-center p-3 bg-light">
                <small class="text-muted">Unread</small>
                <h4 class="fw-bold text-primary mb-0"><?php echo e($unreadCount); ?></h4>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 text-center p-3">
                <small class="text-muted">Read</small>
                <h4 class="fw-bold text-success mb-0"><?php echo e($readCount); ?></h4>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 text-center p-3">
                <small class="text-muted">Today</small>
                <h4 class="fw-bold text-warning mb-0"><?php echo e($todayCount); ?></h4>
            </div>
        </div>
    </div>


    <!-- ===================== FILTERS + ACTIONS ===================== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">

        <!-- Filters -->
        <div class="d-flex flex-wrap gap-2">
            <a href="<?php echo e(route('notifications.index')); ?>"
               class="btn btn-sm btn-outline-secondary rounded-pill">All</a>

            <a href="<?php echo e(route('notifications.index', ['filter' => 'unread'])); ?>"
               class="btn btn-sm btn-outline-primary rounded-pill">Unread</a>

            <a href="<?php echo e(route('notifications.index', ['filter' => 'read'])); ?>"
               class="btn btn-sm btn-outline-success rounded-pill">Read</a>

            <a href="<?php echo e(route('notifications.index', ['date' => '7days'])); ?>"
               class="btn btn-sm btn-outline-info rounded-pill">Last 7 Days</a>

            <a href="<?php echo e(route('notifications.index', ['date' => 'month'])); ?>"
               class="btn btn-sm btn-outline-warning rounded-pill">Last Month</a>
        </div>

        <!-- Right Side Actions -->
        <div class="d-flex gap-2 flex-wrap">

            <!-- Mark All Read -->
            <form method="POST" action="<?php echo e(route('notifications.markAllRead')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-success rounded-pill">
                    <i class="bi bi-check2-all me-1"></i> Mark All Read
                </button>
            </form>

            <!-- Delete All -->
            <button type="button"
                    class="btn btn-sm btn-danger rounded-pill"
                    data-bs-toggle="modal"
                    data-bs-target="#globalDeleteModal"
                    data-action="<?php echo e(route('notifications.deleteAll')); ?>">
                <i class="bi bi-trash me-1"></i> Delete All
            </button>
        </div>
    </div>


    <!-- ===================== BULK FORM START ===================== -->
    <form method="POST" action="<?php echo e(route('notifications.bulkDelete')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <!-- Bulk Controls -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <input type="checkbox" id="selectAll">
                <label for="selectAll" class="ms-1">Select All</label>
            </div>

            <button type="submit"
                    class="btn btn-sm btn-outline-danger rounded-pill"
                    onclick="return confirm('Delete selected notifications?')">
                <i class="bi bi-trash me-1"></i> Delete Selected
            </button>
        </div>


        <!-- ===================== NOTIFICATION LIST ===================== -->
        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="card mb-3 shadow-sm rounded-4
                <?php echo e(is_null($notification->read_at) ? 'border-start border-4 border-primary bg-light' : ''); ?>

                <?php echo e(($notification->data['is_pinned'] ?? false) ? 'border-warning' : ''); ?>">

                <div class="card-body d-flex gap-3 align-items-start">

                    <!-- Checkbox -->
                    <div class="form-check mt-1">
                        <input class="form-check-input notification-checkbox"
                               type="checkbox"
                               name="notification_ids[]"
                               value="<?php echo e($notification->id); ?>">
                    </div>

                    <!-- Content -->
                    <div class="flex-grow-1">

                        <!-- Badges -->
                        <div class="mb-1">

                            <?php if(($notification->data['is_pinned'] ?? false)): ?>
                                <span class="badge bg-warning text-dark rounded-pill">
                                    <i class="bi bi-pin-angle-fill me-1"></i> Pinned
                                </span>
                            <?php endif; ?>

                            <?php if(is_null($notification->read_at)): ?>
                                <span class="badge bg-primary rounded-pill">Unread</span>
                            <?php else: ?>
                                <span class="badge bg-success rounded-pill">Read</span>
                            <?php endif; ?>

                        </div>

                        <!-- Message -->
                        <div class="fw-semibold">
                            <?php echo e($notification->data['message']); ?>

                        </div>

                        <!-- Time -->
                        <div class="text-muted small mt-1">
                            <?php echo e($notification->created_at->format('d M Y, h:i A')); ?>

                            • <?php echo e($notification->created_at->diffForHumans()); ?>

                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="d-flex gap-2 flex-wrap">

                        <!-- View -->
                        <a href="<?php echo e(route('notifications.open', $notification->id)); ?>"
                           class="btn btn-sm btn-primary rounded-pill">
                            <i class="bi bi-eye me-1"></i> View
                        </a>

                        <!-- Pin Toggle -->
                        <form method="POST"
                              action="<?php echo e(route('notifications.togglePin', $notification->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-sm
                                <?php echo e(($notification->data['is_pinned'] ?? false) ? 'btn-warning' : 'btn-outline-warning'); ?>

                                rounded-pill">
                                <i class="bi bi-pin-angle me-1"></i>
                            </button>
                        </form>

                        <!-- Delete -->
                        <button type="button"
                                class="btn btn-sm btn-outline-danger rounded-pill"
                                data-bs-toggle="modal"
                                data-bs-target="#globalDeleteModal"
                                data-action="<?php echo e(route('notifications.destroy', $notification->id)); ?>">
                            <i class="bi bi-trash me-1"></i>
                        </button>

                    </div>

                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-light text-center rounded-4 shadow-sm">
                <i class="bi bi-bell-slash fs-3 mb-2"></i>
                <p class="mb-0">No notifications found.</p>
            </div>
        <?php endif; ?>

    </form>
    <!-- ===================== BULK FORM END ===================== -->


    <!-- ===================== PAGINATION ===================== -->
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($notifications->onEachSide(1)->links('pagination::bootstrap-5')); ?>

    </div>

</div>


<!-- Select All Script -->
<script>
document.getElementById('selectAll').addEventListener('change', function () {
    let checkboxes = document.querySelectorAll('.notification-checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
});
</script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/notifications/index.blade.php ENDPATH**/ ?>