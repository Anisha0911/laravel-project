<div class="d-flex flex-column h-100">

    <div class="sidebar-header">
        <span>Admin Panel</span>
    </div>

    <ul class="nav flex-column p-2 flex-grow-1">

        <li class="nav-item">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                <i class="bi bi-speedometer2"></i>
                <span> Dashboard</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('admin.projects.index')); ?>" class="nav-link <?php echo e(request()->is('admin/projects*') ? 'active' : ''); ?>">
                <i class="bi bi-kanban"></i>
                <span> Projects</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('admin.tasks.index')); ?>" class="nav-link <?php echo e(request()->is('admin/tasks*') ? 'active' : ''); ?>">
                <i class="bi bi-list-task"></i>
                <span> Tasks</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="nav-link <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
                <i class="bi bi-people"></i>
                <span> Users</span>
            </a>
        </li>

    </ul>

    <div class="sidebar-footer">
        <small>Logged in as</small><br>
        <strong><?php echo e(auth()->user()->name); ?></strong>
    </div>

</div>
<?php /**PATH D:\xampp\htdocs\task-management\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>