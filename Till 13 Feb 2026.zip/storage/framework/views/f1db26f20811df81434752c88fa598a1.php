

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">User Dashboard</h2>
</div>

<!-- Stats Cards -->
<div class="row g-4 mb-4">

    <!-- Projects -->
    <div class="col-sm-6 col-lg-4">
        <div class="stat-card bg-gradient-projects">
            <div>
                <small>Total Projects</small>
                <h3 class="fw-bold"><?php echo e($projects); ?></h3>
            </div>
            <i class="bi bi-kanban"></i>
        </div>
    </div>

    <!-- Tasks -->
    <div class="col-sm-6 col-lg-4">
        <div class="stat-card bg-gradient-tasks">
            <div>
                <small>Total Tasks</small>
                <h3 class="fw-bold"><?php echo e($tasks); ?></h3>
            </div>
            <i class="bi bi-list-task"></i>
        </div>
    </div>

    <!-- Completed -->
    <div class="col-sm-6 col-lg-4">
        <div class="stat-card bg-gradient-users">
            <div>
                <small>Completed Tasks</small>
                <h3 class="fw-bold"><?php echo e($completedTasks); ?></h3>
            </div>
            <i class="bi bi-check-circle"></i>
        </div>
    </div>

</div>

<!-- My Projects Table -->
<div class="card shadow-sm border-0">
    <div class="card-header fw-semibold bg-white">
        My Projects
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Project Name</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $myProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($project->name); ?></td>
                    <td>
                        <span class="badge <?php echo e($project->status == 'completed' ? 'bg-success' : 'bg-warning'); ?>">
                            <?php echo e(ucfirst($project->status)); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/dashboard.blade.php ENDPATH**/ ?>