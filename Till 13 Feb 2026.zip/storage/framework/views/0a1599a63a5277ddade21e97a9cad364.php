
<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-4">

    <!-- Page Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Projects</h2>
            <p class="text-muted small">Manage all projects in your system</p>
        </div>

        <a href="/admin/projects/create" class="btn btn-primary rounded-pill px-4">
            <i class="bi bi-plus-lg me-1"></i> Add Project
        </a>
    </div>

    <!-- Projects Table Card -->
    <div class="card border-0 shadow-sm rounded-4">
<div class="card-header bg-white border-0 px-4 pt-4 pb-3">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

        <!-- Left: Title -->
        <div>
            <h5 class="fw-bold mb-1 d-flex align-items-center">
                <i class="bi bi-kanban-fill text-primary me-2"></i>
                Project List
            </h5>
            <small class="text-muted">
                All active and completed projects
            </small>
        </div>

        <!-- Right: Search -->
        <form method="GET" action="<?php echo e(route('admin.projects.index')); ?>">
            <div class="input-group input-group-sm shadow-sm">
                <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-search text-muted"></i>
                </span>
                <input type="text"
                       name="search"
                       value="<?php echo e(request('search')); ?>"
                       class="form-control border-start-0"
                       placeholder="Search projects…">
            </div>
        </form>

    </div>
</div>


        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr class="text-muted small text-uppercase">
                            <th>Project Name</th>
                            <th>Description</th>
                            <th>Assigned To</th>
                            <th>Duration</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <!-- Project Name -->
                            <td class="fw-semibold">
                                <i class="bi bi-folder-fill text-primary me-1"></i>
                                <?php echo e($project->name); ?>

                            </td>

                            <!-- Description -->
                            <td class="text-muted small">
                                <?php echo e(Str::limit($project->description, 60)); ?>

                            </td>

                            <!-- Assigned User -->
                            <td>
                                <?php if($project->user): ?>
                                    <span class="badge bg-light text-dark border px-2 py-1">
                                        <i class="bi bi-person-circle me-1"></i> <?php echo e($project->user->name); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Unassigned</span>
                                <?php endif; ?>
                            </td>

                            <!-- Duration -->
                            <td>
                                <span class="badge bg-light text-dark border">
                                    <?php echo e($project->start_date ? \Carbon\Carbon::parse($project->start_date)->format('d M Y') : 'N/A'); ?>

                                    →
                                    <?php echo e($project->end_date ? \Carbon\Carbon::parse($project->end_date)->format('d M Y') : 'N/A'); ?>

                                </span>
                            </td>

                            <!-- Actions -->
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.projects.edit', $project->id)); ?>"
                                   class="btn btn-sm btn-outline-primary rounded-circle me-1">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <button type="button"
                                        class="btn btn-sm btn-outline-danger rounded-circle"
                                        data-bs-toggle="modal"
                                        data-bs-target="#globalDeleteModal"
                                        data-action="<?php echo e(route('admin.projects.destroy', $project->id)); ?>">
                                    <i class="bi bi-trash"></i>
                                </button>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">
                                <i class="bi bi-folder-x fs-3"></i>
                                <p class="mb-0">No projects found</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

</div>
<script>
document.querySelector('input[name="search"]').addEventListener('keyup', function(e) {
    if (e.key === 'Enter') {
        this.form.submit();
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>