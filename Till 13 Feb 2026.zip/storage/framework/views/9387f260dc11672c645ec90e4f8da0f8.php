<section class="card border-0 shadow-sm rounded-4 mt-4">
    <div class="card-header bg-white border-0 pb-0">
        <h5 class="fw-bold mb-1">Update Password</h5>
        <p class="text-muted small mb-0">
            Use a strong password to keep your account secure.
        </p>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route('password.update')); ?>" class="mt-3">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Current Password -->
            <div class="mb-3">
                <label class="form-label fw-semibold">Current Password</label>
                <input type="password"
                       name="current_password"
                       class="form-control form-control-lg"
                       autocomplete="current-password">

                <?php $__errorArgs = ['current_password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- New Password -->
            <div class="mb-3">
                <label class="form-label fw-semibold">New Password</label>
                <input type="password"
                       name="password"
                       class="form-control form-control-lg"
                       autocomplete="new-password">

                <?php $__errorArgs = ['password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Confirm Password -->
            <div class="mb-3">
                <label class="form-label fw-semibold">Confirm New Password</label>
                <input type="password"
                       name="password_confirmation"
                       class="form-control form-control-lg"
                       autocomplete="new-password">

                <?php $__errorArgs = ['password_confirmation', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Save Button -->
            <div class="d-flex align-items-center gap-3 mt-4">
                <button type="submit" class="btn btn-warning px-4 py-2 rounded-pill">
                    <i class="bi bi-shield-lock me-1"></i> Update Password
                </button>

                <?php if(session('status') === 'password-updated'): ?>
                    <span class="text-success fw-semibold">✔ Password updated</span>
                <?php endif; ?>
            </div>
        </form>
    </div>
</section>
<?php /**PATH D:\xampp\htdocs\task-management\resources\views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>