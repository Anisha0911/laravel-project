
<?php $__env->startSection('content'); ?>

<div class="container mt-5">

    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
        <h2 class="fw-bold mb-3 mb-md-0">Projects</h2>
    </div>

    <!-- Table Card -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Project Name</th>
                            <th>Description</th>
                            <th>Duration</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-semibold">
                                    <?php echo e($project->name); ?>

                                </td>

                                <td class="text-muted">
                                    <?php echo e($project->description ?? '—'); ?>

                                </td>

                                <td>
                                    <span class="text-muted">
                                        <?php echo e($project->start_date ? \Carbon\Carbon::parse($project->start_date)->format('d M Y') : 'N/A'); ?>

                                        —
                                        <?php echo e($project->end_date ? \Carbon\Carbon::parse($project->end_date)->format('d M Y') : 'N/A'); ?>

                                    </span>
                                </td>

                                <td class="text-center">
                                    <?php
                                        $task = $project->tasks()
                                            ->where('user_id', auth()->id())
                                            ->first();
                                    ?>

                                    <?php if($task): ?>
                                        <a href="<?php echo e(route('user.projects.tasks', $project->id)); ?>"
                                           class="btn btn-sm btn-primary">
                                            View My Tasks
                                        </a>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">No tasks</span>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">
                                    No projects assigned to you.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/projects/index.blade.php ENDPATH**/ ?>