
<?php $__env->startSection('content'); ?>

<div class="container mt-5">

    <!-- Page Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
        <h2 class="fw-bold mb-3 mb-md-0">Edit Task</h2>
        <a href="<?php echo e(route('admin.tasks.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to Tasks
        </a>
    </div>

    <!-- Edit Task Form -->
    <div class="card shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('admin.tasks.update', $task->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row g-3">

                    <div class="col-12">
                        <label class="form-label">Task Title</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e($task->title); ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Task Description</label>
                        <textarea name="description" rows="4" class="form-control" required><?php echo e($task->description); ?></textarea>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Project</label>
                        <select name="project_id" class="form-select">
                             <option value="">Select Project</option>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($project->id); ?>" <?php if($project->id==$task->project_id): echo 'selected'; endif; ?>>
                                    <?php echo e($project->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Assign User</label>
                        <select name="user_id" class="form-select">
                             <option value="">Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if($user->role === 'user'): ?>
                                <option value="<?php echo e($user->id); ?>" <?php if($user->id==$task->user_id): echo 'selected'; endif; ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                             <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="">Select Task Status</option>
                            <option value="pending" <?php if($task->status=='pending'): echo 'selected'; endif; ?>>Pending</option>
                            <option value="in_progress" <?php if($task->status=='in_progress'): echo 'selected'; endif; ?>>In Progress</option>
                            <option value="review" <?php if($task->status=='review'): echo 'selected'; endif; ?>>Review</option>
                            <option value="hold" <?php if($task->status=='hold'): echo 'selected'; endif; ?>>Hold</option>
                            <option value="completed" <?php if($task->status=='completed'): echo 'selected'; endif; ?>>Completed</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Due Date</label>
                        <input type="date" name="due_date" value="<?php echo e($task->due_date?->format('Y-m-d')); ?>" class="form-control">
                    </div>

                    <div class="col-12 text-end mt-3">
                        <button type="submit" class="btn btn-primary">Save Task</button>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>

<!-- ================= JS FIXES ================= -->

<script>
let mediaRecorder, audioChunks = [], isRecording = false, stream;

const recordBtn   = document.getElementById('recordBtn');
const preview     = document.getElementById('preview');
const commentForm = document.getElementById('commentForm');

recordBtn.onclick = async () => {

    if (!isRecording) {
        stream = await navigator.mediaDevices.getUserMedia({ audio:true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];

        mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
        mediaRecorder.start();

        isRecording = true;
        recordBtn.innerText = '⏹️ Stop Recording';
        return;
    }

    mediaRecorder.stop();
    isRecording = false;

    mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunks, { type:'audio/webm' });
        preview.src = URL.createObjectURL(blob);
        preview.classList.remove('d-none');

        const file = new File([blob], 'voice.webm', { type:'audio/webm' });
        const dt = new DataTransfer();
        dt.items.add(file);

        // ✅ REMOVE OLD AUDIO INPUT
        const old = commentForm.querySelector('input[name="audio"]');
        if (old) old.remove();

        const input = document.createElement('input');
        input.type = 'file';
        input.name = 'audio';
        input.files = dt.files;

        commentForm.appendChild(input);
        stream.getTracks().forEach(t => t.stop());
        recordBtn.innerText = '🎙️ Start Recording';
    };
};

// ✅ PREVENT DOUBLE SUBMIT
commentForm.addEventListener('submit', () => {
    document.getElementById('submitComment').disabled = true;
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/admin/tasks/edit.blade.php ENDPATH**/ ?>