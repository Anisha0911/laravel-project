<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar-desktop {
            min-height: 100vh;
        }
        .navbar .bi-bell:hover {
            color: #0d6efd; /* Bootstrap primary color */
            transform: scale(1.2);
            transition: transform 0.2s, color 0.2s;
        }
        .alert-dismissible {
            transform: translateY(-20px);
            opacity: 0;
            transition: transform 0.5s ease, opacity 0.5s ease;
        }
        .alert-dismissible.show {
            transform: translateY(0);
            opacity: 1;
        }
    </style>
</head>
<body>

<!-- TOP NAVBAR -->
<?php
    $panelName = auth()->user()->role === 'admin' ? 'Admin Panel' : 'User Panel';
    $profileRoute = auth()->user()->role === 'admin'
        ? route('admin.profile.edit')
        : route('user.profile.edit');

    $dashboardRoute = auth()->user()->role === 'admin'
        ? route('admin.dashboard')
        : route('user.dashboard');
?>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container-fluid">

        <!-- Mobile toggle -->
        <button class="btn btn-outline-secondary d-lg-none"
                data-bs-toggle="offcanvas"
                data-bs-target="#mobileSidebar">
            <i class="bi bi-list"></i>
        </button>

        <span class="navbar-brand fw-bold ms-2"><?php echo e($panelName); ?></span>

        <a href="<?php echo e(route('notifications.index')); ?>" class="position-relative text-dark me-3">
            <i class="bi bi-bell fs-4"></i>
            <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo e(auth()->user()->unreadNotifications->count()); ?>

                    <span class="visually-hidden">unread notifications</span>
                </span>
            <?php endif; ?>
        </a>

        <div class="ms-auto dropdown">
            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle"
               data-bs-toggle="dropdown">
                <i class="bi bi-person-circle fs-4 me-2"></i>
                <span><?php echo e(auth()->user()->name); ?></span>
            </a>

            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                <!-- Profile Link -->
                <li>
                    <a href="<?php echo e($profileRoute); ?>" class="dropdown-item">
                        <i class="bi bi-person me-2"></i> Edit Profile
                    </a>
                </li>

                <li><hr class="dropdown-divider"></li>

                <!-- Logout -->
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="dropdown-item text-danger">
                            <i class="bi bi-box-arrow-right me-2"></i> Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>

    </div>
</nav>

<div class="container-fluid">
    <div class="row">

        <!-- DESKTOP SIDEBAR -->
        <div class="col-lg-2 d-none d-lg-block p-0 border-end sidebar-desktop">
            <?php if(auth()->user()->role == 'admin'): ?>
                <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>

        <!-- MAIN CONTENT -->
        <div class="col-12 col-lg-10 p-4">
            <?php if(session('success')): ?>
                <div id="successAlert" class="alert alert-success alert-dismissible fade position-fixed top-1 start-50 translate-middle-x mt-3 z-index-1050" role="alert" style="min-width: 300px;">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div id="errorAlert" class="alert alert-danger alert-dismissible fade position-fixed top-1 start-50 translate-middle-x mt-3 z-index-1050" role="alert" style="min-width: 300px;">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>
</div>

<!-- MOBILE SIDEBAR -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">
            <?php if(auth()->user()->role == 'admin'): ?> Admin Menu <?php else: ?> User Menu <?php endif; ?>
        </h5>
        <button class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body p-0">
        <?php if(auth()->user()->role == 'admin'): ?>
            <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('components.delete-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/delete-modal.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\task-management\resources\views/layouts/admin.blade.php ENDPATH**/ ?>