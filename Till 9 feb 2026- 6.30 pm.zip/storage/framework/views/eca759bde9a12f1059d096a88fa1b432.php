

<?php $__env->startSection('content'); ?>

<div class="container mt-5">

    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
        <h2 class="fw-bold mb-3 mb-md-0">All Tasks</h2>
    </div>

    <!-- Table Card -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Title</th>
                            <th>Project</th>
                            <th>Status</th>
                            <th>Due Date</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-semibold">
                                    <?php echo e($task->title); ?>

                                </td>

                                <td class="text-muted">
                                    <?php echo e($task->project->name ?? '—'); ?>

                                </td>

                                <td>
                                    <?php
                                        $statusClass = match($task->status) {
                                            'completed' => 'success',
                                            'in_progress' => 'warning',
                                            'pending' => 'secondary',
                                            default => 'dark'
                                        };
                                    ?>

                                    <span class="badge bg-<?php echo e($statusClass); ?>">
                                        <?php echo e(ucfirst(str_replace('_', ' ', $task->status))); ?>

                                    </span>
                                </td>

                                <td class="text-muted">
                                    <?php echo e($task->due_date ? $task->due_date->format('d M Y') : 'N/A'); ?>

                                </td>

                                <td class="text-center">
                                    <a href="<?php echo e(route('user.tasks.show', $task)); ?>"
                                       class="btn btn-sm btn-primary">
                                        View Task
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    No tasks assigned to you.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task-management\resources\views/user/tasks/index.blade.php ENDPATH**/ ?>