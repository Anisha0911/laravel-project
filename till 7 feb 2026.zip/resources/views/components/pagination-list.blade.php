@props([
    'items',      // The paginated data
    'title' => '', // Optional title for empty message
    'showCard' => true // Wrap each item in a card
])

<!-- Loop through items -->
@forelse($items as $item)
    @if($showCard)
        <div class="card mb-2 shadow-sm">
            <div class="card-body">
                {{ $item->name ?? $item->title ?? $item->data['message'] ?? '' }}
                @if(property_exists($item, 'created_at'))
                    <div class="text-muted small">{{ $item->created_at->diffForHumans() }}</div>
                @endif
            </div>
        </div>
    @else
        <div class="mb-2">
            {{ $item->name ?? $item->title ?? $item->data['message'] ?? '' }}
        </div>
    @endif
@empty
    <div class="alert alert-light text-center">
        No {{ $title ?: 'records' }} found.
    </div>
@endforelse

<!-- Pagination Links -->
@if($items->hasPages())
<div class="d-flex justify-content-center mt-3">
    {{ $items->onEachSide(1)->links('pagination::bootstrap-5') }}
</div>
@endif
